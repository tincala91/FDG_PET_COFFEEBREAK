%-----------------------------------------------------------------------
% Job saved on 28-Oct-2020 22:28:49 by cfg_util (rev $Rev: 6460 $)
% spm SPM - SPM12 (6685)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.stats.factorial_design.dir = '<UNDEFINED>';
matlabbatch{1}.spm.stats.factorial_design.des.t2.scans1 = '<UNDEFINED>';
%%% %*******please replace C:\Users\asala\Desktop\SCRIPT with the path to the script
%%% folder!****
matlabbatch{1}.spm.stats.factorial_design.des.t2.scans2 = {
                                                           'CHANGEMEPLEASE\sws0042855A-207260-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\sws0055474Q-419110-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\sws0152256K-866740-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\sws0228866K-714870-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\sws0317717H-340790-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\sws0502130L-831340-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\sws0582584R-898820-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\sws0625676B-306400-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\sws3310574Q-58250-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\sws6031272L-14440-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\sws6254700X-582150-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900065-95220-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900066-121980-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900070-308360-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900071-157440-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900075-386980-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900082-520830-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900083-568840-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900084-393230-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900085-427300-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900088-563330-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900094-552000-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900095-731030-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900096-767100-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900097-584700-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900106-988230-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900124-288560-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900126-120750-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900130-483320-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900146-893690-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900147-919340-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900148-761150-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900158-980670-00001-000001.img,1'
                                                           'CHANGEMEPLEASE\swsGERA2900169-306710-00001-000001.img,1'
                                                           };
%%
matlabbatch{1}.spm.stats.factorial_design.des.t2.dept = 0;
matlabbatch{1}.spm.stats.factorial_design.des.t2.variance = 1;
matlabbatch{1}.spm.stats.factorial_design.des.t2.gmsca = 1;
matlabbatch{1}.spm.stats.factorial_design.des.t2.ancova = 0;
matlabbatch{1}.spm.stats.factorial_design.cov = struct('c', {}, 'cname', {}, 'iCFI', {}, 'iCC', {});
matlabbatch{1}.spm.stats.factorial_design.multi_cov = struct('files', {}, 'iCFI', {}, 'iCC', {});
matlabbatch{1}.spm.stats.factorial_design.masking.tm.tmr.rthresh = 0.8;
matlabbatch{1}.spm.stats.factorial_design.masking.im = 1;
matlabbatch{1}.spm.stats.factorial_design.masking.em = '<UNDEFINED>';
matlabbatch{1}.spm.stats.factorial_design.globalc.g_mean = 1;
matlabbatch{1}.spm.stats.factorial_design.globalm.gmsca.gmsca_yes.gmscv = 50;
matlabbatch{1}.spm.stats.factorial_design.globalm.glonorm = 2;
matlabbatch{2}.spm.stats.fmri_est.spmmat(1) = cfg_dep('Factorial design specification: SPM.mat File', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{2}.spm.stats.fmri_est.write_residuals = 0;
matlabbatch{2}.spm.stats.fmri_est.method.Classical = 1;
matlabbatch{3}.spm.stats.con.spmmat(1) = cfg_dep('Model estimation: SPM.mat File', substruct('.','val', '{}',{2}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{3}.spm.stats.con.consess{1}.tcon.name = 'Hypo';
matlabbatch{3}.spm.stats.con.consess{1}.tcon.weights = [-1 1];
matlabbatch{3}.spm.stats.con.consess{1}.tcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.consess{2}.tcon.name = 'Pres';
matlabbatch{3}.spm.stats.con.consess{2}.tcon.weights = [1 -1];
matlabbatch{3}.spm.stats.con.consess{2}.tcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.delete = 0;
matlabbatch{4}.spm.stats.results.spmmat(1) = cfg_dep('Contrast Manager: SPM.mat File', substruct('.','val', '{}',{3}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{4}.spm.stats.results.conspec.titlestr = '';
matlabbatch{4}.spm.stats.results.conspec.contrasts = 1;
matlabbatch{4}.spm.stats.results.conspec.threshdesc = 'none';
matlabbatch{4}.spm.stats.results.conspec.thresh = 0.05;
matlabbatch{4}.spm.stats.results.conspec.extent = 0;
matlabbatch{4}.spm.stats.results.conspec.conjunction = 1;
matlabbatch{4}.spm.stats.results.conspec.mask.none = 1;
matlabbatch{4}.spm.stats.results.units = 1;
matlabbatch{4}.spm.stats.results.print = 'jpg';
matlabbatch{4}.spm.stats.results.write.tspm.basename = 'Hypo';
matlabbatch{5}.spm.stats.results.spmmat(1) = cfg_dep('Contrast Manager: SPM.mat File', substruct('.','val', '{}',{3}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{5}.spm.stats.results.conspec.titlestr = '';
matlabbatch{5}.spm.stats.results.conspec.contrasts = 2;
matlabbatch{5}.spm.stats.results.conspec.threshdesc = 'none';
matlabbatch{5}.spm.stats.results.conspec.thresh = 0.05;
matlabbatch{5}.spm.stats.results.conspec.extent = 0;
matlabbatch{5}.spm.stats.results.conspec.conjunction = 1;
matlabbatch{5}.spm.stats.results.conspec.mask.none = 1;
matlabbatch{5}.spm.stats.results.units = 1;
matlabbatch{5}.spm.stats.results.print = 'jpg';
matlabbatch{5}.spm.stats.results.write.tspm.basename = 'Pres';
