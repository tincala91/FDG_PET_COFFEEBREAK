%declaring useful variables
global baseDir
global subj_code
dir_dicom=pwd;
smoothedImg=strcat(dir_dicom,'\','swcounts_',subj_code,'.nii');

% List of open inputs
% Factorial design specification: Directory - cfg_files
% Factorial design specification: Group 1 scans - cfg_files
nrun = 1; % enter the number of runs here
jobfile = cellstr(fullfile(baseDir,'JOB_FILES\STAT_script_job.m'));
jobs = repmat(jobfile, 1, nrun);
inputs = cell(3, nrun);
for crun = 1:nrun
    inputs{1, crun} = cellstr(dir_dicom); % Factorial design specification: Directory - cfg_files
    inputs{2, crun} = cellstr(smoothedImg); % Factorial design specification: Group 1 scans - cfg_files
    inputs{3, crun} = cellstr(fullfile(baseDir,'MASK_TEMPLATES_HC\brainmask.nii')); %Factorial design specification: Group 2 scans - cfg_files
    end
spm('defaults', 'PET');
spm_jobman('run', jobs, inputs{:});
